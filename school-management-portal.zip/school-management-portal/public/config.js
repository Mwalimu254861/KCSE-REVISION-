// For web hosting, leave blank to use same-origin /api.
// For Android APK, set this to your deployed backend HTTPS URL before building.
window.PORTAL_API_URL = '';
